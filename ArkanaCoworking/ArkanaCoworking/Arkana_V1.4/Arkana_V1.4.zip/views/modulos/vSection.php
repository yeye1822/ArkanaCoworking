 <!--Hero section -->
<section class="hero-section">
	<div class="hero-slider owl-carousel">
		<div class="hs-item set-bg" data-setbg="img/slider/1.jpg" data-hash="slide-1">
			<div class="container">
				<h2>Disfrutamos lo que hacemos</h2>
				<!-- <a href="#" class="site-btn">Ver Más<i class="fa fa-angle-double-right"></i></a> -->
			</div>
			<div class="next-hs set-bg" data-setbg="img/slider/2.jpg">
				<a href="#slide-2" class="nest-hs-btn">Siguiente</a>
			</div>
		</div>
		<div class="hs-item set-bg" data-setbg="img/slider/2.jpg" data-hash="slide-2">
			<div class="container">
				<h2>Descubrir tu pasión lo cambia todo</h2>
				<!-- <a href="#" class="site-btn">Ver Más<i class="fa fa-angle-double-right"></i></a> -->
			</div>
			<div class="next-hs set-bg" data-setbg="img/slider/1.jpg">
				<a href="#slide-1" class="nest-hs-btn">Siguiente</a>
			</div>
		</div>
	</div>
	<div class="hero-social-warp">
		<p>Nuestras Redes Sociales</p>
		<div class="hero-social-links">
			<!-- <a href="#"><i class="fa fa-behance"></i></a>
			<a href="#"><i class="fa fa-dribbble" target="_blank"></i></a> 
			<a href="#"><i class="fa fa-twitter" target="_blank"></i></a>
			<a href="#"><i class="fa fa-facebook" target="_blank"></i></a>
			<a href="#"><i class="fa fa-instagram" target="_blank"></i></a>-->

   <a href=""><i class="fa fa-linkedin"></i></a>
                                       <!-- <a href="#"><i class="fa fa-whatsapp"></i></a>-->
					<a href="https://www.instagram.com/arkanacoworking/" target="_blank"><i class="fa fa-instagram"></i></a>
					<a href="https://www.facebook.com/Arkana-Coworking-106267884068140/" target="_blank"><i class="fa fa-facebook" ></i></a>
					<a href="https://twitter.com/ARKANACOWORKING" target="_blank"><i class="fa fa-twitter"></i></a>


		</div>
	</div>
</section>
<!-- Hero section end