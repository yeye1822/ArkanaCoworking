<!-- Footer section -->
<footer class="footer-section bg-dark text-white">
	<div class="container">
		<div class="row">
			<div class="col-lg-6 col-sm-6 text-center">
				<!--<img src="img/arkana.png" alt="" width="200">	-->
				<i class="fa fa-map-marker" aria-hidden="true" style="font-size: 50px;"></i>
				<br>

<ul class="btn" style="list-style: none;">
						<li>Dirección: Km 7 Vía Rionegro - Llanogrande, Antioquia</li>
						<li>Sede Llanogrande</li>
						
					</ul>
			</div>
			<div class="col-lg-6 col-sm-6 text-center">
			<i class="fa fa-map-marker" aria-hidden="true" style="font-size: 50px;"></i>
				<br>
					<ul class="btn" style="list-style: none;">
						<li>Vía aeropuerto, Km 2.2, Cl. 51, Rionegro, Antioquia</li>
						<li>Sede Porta nova</li>
					</ul>

					
			</div>
		</div>

		<div class="row text-center">
<div class="col-lg-12 col-sm-12 mt-5">

<a href=""><i class="fa fa-linkedin pr-1"></i></a>
                                      
					<a href="https://www.instagram.com/arkanacoworking/" target="_blank"><i class="fa fa-instagram pr-1"></i></a>
					<a href="https://www.facebook.com/Arkana-Coworking-106267884068140/" target="_blank"><i class="fa fa-facebook pr-1" ></i></a>
					<a href="https://twitter.com/ARKANACOWORKING" target="_blank"><i class="fa fa-twitter"></i></a>

					</div>
<div class="col-lg-12 pt-2 pb-2 text-center">info@arkanacoworking.com</div>
			<div class="col-lg-12">
				Copyright &copy;<script>document.write(new Date().getFullYear());</script> Todos los derechos reservados | Hecho con Amor <i class="fa fa-heart-o" aria-hidden="true"></i> <a href="#" target="_blank">Arkana Coworking</a>
			</div>
		</div>
	</div>
</footer>
<div id="btnWhatsapp">  
     <script>

        if( /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ) {
            document.write('<a href="https://api.whatsapp.com/send?phone=573118026754" target="_blank"> <i class="fa fa-whatsapp" aria-hidden="true" style="color:#fff;font-size:30px;padding:9px 10px;"></i> </a>');
        }else{
            document.write('<a href="https://web.whatsapp.com//send?phone=573118026754" target="_blank"> <i class="fa fa-whatsapp" aria-hidden="true" style="color:#fff;font-size:30px;padding:9px 10px;"></i></a>');
        }

    </script>

</div>

<div class="btnSubirD" id="subirD">
	<img src="img/arriba.png" alt="subir" style="width: 48px; cursor: pointer;" title="Subir">
</div>
