 <!--Intro section -->
<section class="intro-section spad" id="plan">
	<div class="container">
		<div class="row">
			<div class="col-lg-5">
				<img src="img/cup.jpg" alt="">
			</div>
			<div class="col-lg-7 intro-text">
				<span>Arkana Coworking</span>
				<h2>Abriendo Caminos, Cerrando Proyectos.</h2>
				<p class="text-justify">ARKANA COWORKING es un espacio de trabajo compartido, diseñado para trabajar en sus proyectos y disfrutar un ambiente tranquilo.
Permite trabajar en diferentes áreas del conocimiento, fácil acceso, sin tarifa de entrada y sin depósitos, sólo paga por el tiempo usado. 
Disfrute del espacio de la oficina privada, espacios compartidos, consultorio privado, puesto fijo, sala de reuniones y de una vibrante atmósfera natural de trabajo compartido en Arkana Coworking.
</p>
				<!-- <a href="#" class="site-btn sb-dark">Read More <i class="fa fa-angle-double-right"></i></a> -->
			</div>
		</div>
	</div>
</section>
<!-- Intro section end-->